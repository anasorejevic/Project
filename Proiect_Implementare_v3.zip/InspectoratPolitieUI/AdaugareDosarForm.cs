﻿using InspectoratPolitieLibrary;
using InspectoratPolitieLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InspectoratPolitieUI
{
    public partial class AdaugareDosarForm : Form
    {
        string nextpage;
        List<AgentPolitieModel> agentPolitieLista = new List<AgentPolitieModel>();

        public AdaugareDosarForm()
        {
            InitializeComponent();

            AgentPolitieDataAccess dataAccess = new AgentPolitieDataAccess();
            agentPolitieLista = dataAccess.GetAllAgents();
            checkedListBoxAgenti.DataSource = agentPolitieLista;
        }

        public string GetNextPage()
        {
            return nextpage;
        }
        private void buttonCreareDosar_Click(object sender, EventArgs e)
        {
            DosarModel dosarModel = new DosarModel();




            List<AgentPolitieModel> agentiSelectati = new List<AgentPolitieModel>();



            for (int i = 0; i < checkedListBoxAgenti.Items.Count; i++)
            {
                if (checkedListBoxAgenti.GetItemChecked(i))
                {
                    agentiSelectati.Add(agentPolitieLista[i]);
                }
            }

            dosarModel.Participanti = agentiSelectati;


            dosarModel.NumeDosar = textBoxNumeDosar.Text.ToString();

            
            dosarModel.Continut = textBoxContinut.Text.ToString(); ;

            AdaugaDosar adaugaDosar = new AdaugaDosar(dosarModel);
            adaugaDosar.AddDosarToDb();

            MessageBox.Show("Date introduse cu succes");
        }

        private void linkLabelSectii_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "AdaugareSectieForm";
            this.Close();
        }

        private void linkLabelSedinte_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "PaginaPrincipalaForm";
            this.Close();
        }

        private void linkLabelDosare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "AdaugareDosarForm";
            this.Close();
        }

        private void buttonVizualizareDosare_Click(object sender, EventArgs e)
        {
            this.nextpage = "PaginaDosareForm";
            this.Close();
        }

        
    }
}
