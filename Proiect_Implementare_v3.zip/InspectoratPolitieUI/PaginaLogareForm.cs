using InspectoratPolitieLibrary.Services;

namespace InspectoratPolitieUI
{
    public partial class PaginaLogareForm : Form
    {

        private string nextpage;
        private string usertype;

        public PaginaLogareForm()
        {

            InitializeComponent();
        }

        internal string GetNextPage()
        {
            return this.nextpage;
        }

        internal string GetUsertype() 
        { 
            return this.usertype; 
        }

        private void buttonLogare_Click(object sender, EventArgs e)
        {
            LogareService logareService = new LogareService();

            logareService.email = Email.Text.ToString();
            logareService.parola = Prenume.Text.ToString();

            if (logareService.VerificaDateAgent() == true)
            {
                this.nextpage = "PaginaPrincipalaForm";
                usertype = "agent";
                this.Close();
            }
            else if (logareService.VerificaDateAdmin() == true) 
            {
                this.nextpage = "PaginaPrincipalaForm";
                usertype = "admin";
                this.Close();
            }
            else if (logareService.VerificaDateSefInspectorat() == true)
            {
                this.nextpage = "PaginaPrincipalaForm";
                usertype = "sefinspectorat";
                this.Close();
            }
        }

        private void textBoxNume_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxPrenume_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxIdAgent_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxEmailAgent_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void PaginaLogareForm_Load(object sender, EventArgs e)
        {

        }
    }
}