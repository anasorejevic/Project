﻿namespace InspectoratPolitieUI
{
    partial class PaginaSedinteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button1 = new Button();
            listView1 = new ListView();
            linkLabel3 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            button3 = new Button();
            checkedListBoxSedinte = new CheckedListBox();
            textBox1 = new TextBox();
            buttonTrimite = new Button();
            richTextBox1 = new RichTextBox();
            textBox2 = new TextBox();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(701, 442);
            button2.Name = "button2";
            button2.Size = new Size(177, 42);
            button2.TabIndex = 20;
            button2.Text = "Participa";
            button2.UseVisualStyleBackColor = true;
            button2.Click += buttonParticipa_Click;
            // 
            // button1
            // 
            button1.Location = new Point(200, 442);
            button1.Name = "button1";
            button1.Size = new Size(177, 42);
            button1.TabIndex = 19;
            button1.Text = "AdaugaSedinta";
            button1.UseVisualStyleBackColor = true;
            button1.Click += buttonAdaugaSedinta_Click;
            // 
            // listView1
            // 
            listView1.Location = new Point(200, 38);
            listView1.Name = "listView1";
            listView1.Size = new Size(677, 369);
            listView1.TabIndex = 18;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // linkLabel3
            // 
            linkLabel3.BorderStyle = BorderStyle.FixedSingle;
            linkLabel3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel3.Location = new Point(13, 175);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(140, 39);
            linkLabel3.TabIndex = 17;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Dosare";
            linkLabel3.TextAlign = ContentAlignment.TopCenter;
            linkLabel3.LinkClicked += linkLabelDosare_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.BorderStyle = BorderStyle.FixedSingle;
            linkLabel2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel2.Location = new Point(13, 105);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(140, 39);
            linkLabel2.TabIndex = 16;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Sectii";
            linkLabel2.TextAlign = ContentAlignment.TopCenter;
            linkLabel2.LinkClicked += linkLabelSectii_LinkClicked;
            // 
            // linkLabel1
            // 
            linkLabel1.BorderStyle = BorderStyle.FixedSingle;
            linkLabel1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(13, 38);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(140, 39);
            linkLabel1.TabIndex = 15;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Sedinte";
            linkLabel1.TextAlign = ContentAlignment.TopCenter;
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // button3
            // 
            button3.Location = new Point(446, 442);
            button3.Name = "button3";
            button3.Size = new Size(177, 42);
            button3.TabIndex = 21;
            button3.Text = "VizualizareSedinte";
            button3.UseVisualStyleBackColor = true;
            // 
            // checkedListBoxSedinte
            // 
            checkedListBoxSedinte.FormattingEnabled = true;
            checkedListBoxSedinte.Location = new Point(225, 50);
            checkedListBoxSedinte.Name = "checkedListBoxSedinte";
            checkedListBoxSedinte.Size = new Size(117, 328);
            checkedListBoxSedinte.TabIndex = 22;
            checkedListBoxSedinte.SelectedIndexChanged += checkedListBox1_SelectedIndexChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(412, 344);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(281, 23);
            textBox1.TabIndex = 23;
            // 
            // buttonTrimite
            // 
            buttonTrimite.Location = new Point(736, 344);
            buttonTrimite.Name = "buttonTrimite";
            buttonTrimite.Size = new Size(75, 23);
            buttonTrimite.TabIndex = 24;
            buttonTrimite.Text = "Trimite";
            buttonTrimite.UseVisualStyleBackColor = true;
            buttonTrimite.Click += buttonTrimite_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            richTextBox1.Location = new Point(412, 90);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.RightToLeft = RightToLeft.Yes;
            richTextBox1.Size = new Size(399, 224);
            richTextBox1.TabIndex = 25;
            richTextBox1.Text = "";
            richTextBox1.TextChanged += richTextBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(486, 54);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(239, 23);
            textBox2.TabIndex = 26;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // PaginaSedinteForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1148, 589);
            Controls.Add(textBox2);
            Controls.Add(richTextBox1);
            Controls.Add(buttonTrimite);
            Controls.Add(textBox1);
            Controls.Add(checkedListBoxSedinte);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(listView1);
            Controls.Add(linkLabel3);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Name = "PaginaSedinteForm";
            Text = "PaginaSedinteForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private ListView listView1;
        private LinkLabel linkLabel3;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
        private Button button3;
        private CheckedListBox checkedListBoxSedinte;
        private TextBox textBox1;
        private Button buttonTrimite;
        private RichTextBox richTextBox1;
        private TextBox textBox2;
    }
}