namespace InspectoratPolitieUI
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            string nextPage;
            string usertype = "";

            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            DashBoardForm dashBoardForm = new DashBoardForm();
            Application.Run(dashBoardForm);
            nextPage = dashBoardForm.GetNextPage();

            while (true)
            {

                if (nextPage == "PaginaLogareForm")
                {
                    PaginaLogareForm paginaLogareForm = new PaginaLogareForm();
                    Application.Run(paginaLogareForm);
                    nextPage = paginaLogareForm.GetNextPage();
                    usertype = paginaLogareForm.GetUsertype();

                }
                else if (nextPage == "AdaugareContForm")
                {
                    AdaugareContForm adaugareContForm = new AdaugareContForm();
                    Application.Run(adaugareContForm);
                    nextPage = adaugareContForm.GetNextPage();
                }
                else if (nextPage == "DashBoardForm")
                {
                    DashBoardForm dashBoardForm_2 = new DashBoardForm();
                    Application.Run(dashBoardForm_2);
                    nextPage = dashBoardForm_2.GetNextPage();

                }
                else if (nextPage == "PaginaPrincipalaForm")
                {
                    PaginaPrincipalaForm paginaPrincipalaForm = new PaginaPrincipalaForm();
                    paginaPrincipalaForm.SetUserType(usertype);
                    Application.Run(paginaPrincipalaForm);
                    nextPage = paginaPrincipalaForm.GetNextPage();

                }
                else if (nextPage == "PaginaSedinteForm")
                {
                    PaginaSedinteForm paginaSedinteForm = new PaginaSedinteForm();
                    Application.Run(paginaSedinteForm);
                    nextPage = paginaSedinteForm.GetNextPage();

                }
                else if (nextPage == "PaginaSectiiPolitieForm")
                {
                    PaginaSectiiPolitieForm paginaSectiiPolitieForm = new PaginaSectiiPolitieForm();
                    Application.Run(paginaSectiiPolitieForm);
                    nextPage = paginaSectiiPolitieForm.GetNextPage();

                }
                else if (nextPage == "AdaugareSectieForm")
                {
                    AdaugareSectieForm adaugareSectieForm = new AdaugareSectieForm();
                    Application.Run(adaugareSectieForm);
                    nextPage = adaugareSectieForm.GetNextPage();
                }
                else if( nextPage == "AdaugareDosarForm")
                {
                    AdaugareDosarForm adaugareDosarForm = new AdaugareDosarForm();
                    Application.Run(adaugareDosarForm);
                    nextPage = adaugareDosarForm.GetNextPage();
                }
                else if( nextPage == "PaginaDosareForm")
                {
                    PaginaDosareForm aginaDosareForm = new PaginaDosareForm();
                    Application.Run(aginaDosareForm);
                    nextPage = aginaDosareForm.GetNextPage();
                }           
                else
                {
                    break;
                }
            }


        }
    }
}