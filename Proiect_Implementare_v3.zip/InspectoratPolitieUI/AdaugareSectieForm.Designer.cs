﻿namespace InspectoratPolitieUI
{
    partial class AdaugareSectieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button3 = new Button();
            labelSelectareAgenti = new Label();
            checkedListBoxAgenti = new CheckedListBox();
            textBoxLocatie = new TextBox();
            textBoxNumeSectie = new TextBox();
            labelLocatie = new Label();
            labelNumeSectie = new Label();
            buttonCreareSedinta = new Button();
            button1 = new Button();
            listView1 = new ListView();
            linkLabel3 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // button3
            // 
            button3.Location = new Point(708, 438);
            button3.Name = "button3";
            button3.Size = new Size(177, 42);
            button3.TabIndex = 31;
            button3.Text = "VizualizareSectii";
            button3.UseVisualStyleBackColor = true;
            button3.Click += buttonVizualizareSectii_Click;
            // 
            // labelSelectareAgenti
            // 
            labelSelectareAgenti.AutoSize = true;
            labelSelectareAgenti.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelSelectareAgenti.Location = new Point(236, 154);
            labelSelectareAgenti.Name = "labelSelectareAgenti";
            labelSelectareAgenti.Size = new Size(118, 21);
            labelSelectareAgenti.TabIndex = 30;
            labelSelectareAgenti.Text = "SelectareAgenti";
            labelSelectareAgenti.Click += labelSelectareAgenti_Click;
            // 
            // checkedListBoxAgenti
            // 
            checkedListBoxAgenti.FormattingEnabled = true;
            checkedListBoxAgenti.Location = new Point(381, 154);
            checkedListBoxAgenti.Name = "checkedListBoxAgenti";
            checkedListBoxAgenti.Size = new Size(323, 238);
            checkedListBoxAgenti.TabIndex = 29;
            checkedListBoxAgenti.SelectedIndexChanged += checkedListBoxAgenti_SelectedIndexChanged;
            // 
            // textBoxContinut
            // 
            textBoxLocatie.Location = new Point(421, 92);
            textBoxLocatie.Name = "textBoxLocatie";
            textBoxLocatie.Size = new Size(139, 23);
            textBoxLocatie.TabIndex = 27;
            textBoxLocatie.TextChanged += textBoxLocatie_TextChanged;
            // 
            // textBoxNumeDosar
            // 
            textBoxNumeSectie.Location = new Point(421, 60);
            textBoxNumeSectie.Name = "textBoxNumeSectie";
            textBoxNumeSectie.Size = new Size(139, 23);
            textBoxNumeSectie.TabIndex = 26;
            textBoxNumeSectie.TextChanged += textBoxNume_TextChanged;
            // 
            // label1
            // 
            labelLocatie.AutoSize = true;
            labelLocatie.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelLocatie.Location = new Point(304, 90);
            labelLocatie.Name = "labelLocatie";
            labelLocatie.Size = new Size(59, 21);
            labelLocatie.TabIndex = 25;
            labelLocatie.Text = "Locatie";
            labelLocatie.Click += labelLocatie_Click;
            // 
            // label2
            // 
            labelNumeSectie.AutoSize = true;
            labelNumeSectie.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelNumeSectie.Location = new Point(304, 60);
            labelNumeSectie.Name = "labelNumeSectie";
            labelNumeSectie.Size = new Size(94, 21);
            labelNumeSectie.TabIndex = 23;
            labelNumeSectie.Text = "NumeSectie";
            labelNumeSectie.Click += labelNumeSectie_Click;
            // 
            // buttonCreareSedinta
            // 
            buttonCreareSedinta.Location = new Point(606, 60);
            buttonCreareSedinta.Name = "buttonCreareSedinta";
            buttonCreareSedinta.Size = new Size(116, 23);
            buttonCreareSedinta.TabIndex = 22;
            buttonCreareSedinta.Text = "CreareSectie";
            buttonCreareSedinta.UseVisualStyleBackColor = true;
            buttonCreareSedinta.Click += buttonCreareSectie_Click;
            // 
            // button1
            // 
            button1.Location = new Point(207, 438);
            button1.Name = "button1";
            button1.Size = new Size(177, 42);
            button1.TabIndex = 20;
            button1.Text = "AdaugaSectie";
            button1.UseVisualStyleBackColor = true;
            button1.Click += buttonAdaugaSectie_Click;
            // 
            // listView1
            // 
            listView1.Location = new Point(208, 34);
            listView1.Name = "listView1";
            listView1.Size = new Size(677, 369);
            listView1.TabIndex = 19;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // linkLabel3
            // 
            linkLabel3.BorderStyle = BorderStyle.FixedSingle;
            linkLabel3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel3.Location = new Point(20, 171);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(140, 39);
            linkLabel3.TabIndex = 18;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Dosare";
            linkLabel3.TextAlign = ContentAlignment.TopCenter;
            linkLabel3.LinkClicked += linkLabelDoasre_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.BorderStyle = BorderStyle.FixedSingle;
            linkLabel2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel2.Location = new Point(20, 101);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(140, 39);
            linkLabel2.TabIndex = 17;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Sectii";
            linkLabel2.TextAlign = ContentAlignment.TopCenter;
            linkLabel2.LinkClicked += linkLabel2_LinkClicked;
            // 
            // linkLabel1
            // 
            linkLabel1.BorderStyle = BorderStyle.FixedSingle;
            linkLabel1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(20, 34);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(140, 39);
            linkLabel1.TabIndex = 16;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Sedinte";
            linkLabel1.TextAlign = ContentAlignment.TopCenter;
            linkLabel1.LinkClicked += linkLabelSedinte_LinkClicked;
            // 
            // AdaugareSectieForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1033, 560);
            Controls.Add(button3);
            Controls.Add(labelSelectareAgenti);
            Controls.Add(checkedListBoxAgenti);
            Controls.Add(textBoxLocatie);
            Controls.Add(textBoxNumeSectie);
            Controls.Add(labelLocatie);
            Controls.Add(labelNumeSectie);
            Controls.Add(buttonCreareSedinta);
            Controls.Add(button1);
            Controls.Add(listView1);
            Controls.Add(linkLabel3);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Name = "AdaugareSectieForm";
            Text = "PaginaSectiiPolitieForm";
            Load += PaginaSectiiPolitieForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button3;
        private Label labelSelectareAgenti;
        private CheckedListBox checkedListBoxAgenti;
        private TextBox textBoxLocatie;
        private TextBox textBoxNumeSectie;
        private Label labelLocatie;
        private Label labelNumeSectie;
        private Button buttonCreareSedinta;
        private Button button1;
        private ListView listView1;
        private LinkLabel linkLabel3;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
    }
}