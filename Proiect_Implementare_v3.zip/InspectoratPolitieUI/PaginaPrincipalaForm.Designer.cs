﻿namespace InspectoratPolitieUI
{
    partial class PaginaPrincipalaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            linkLabel1 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel3 = new LinkLabel();
            listView1 = new ListView();
            button1 = new Button();
            button2 = new Button();
            buttonCreareSedinta = new Button();
            labelNume = new Label();
            labelData = new Label();
            labelGazda = new Label();
            textBoxNume = new TextBox();
            textBoxData = new TextBox();
            textBoxGazda = new TextBox();
            checkedListBoxAgenti = new CheckedListBox();
            labelSelectareAgenti = new Label();
            button3 = new Button();
            linkLabel5 = new LinkLabel();
            linkLabel4 = new LinkLabel();
            SuspendLayout();
            // 
            // linkLabel1
            // 
            linkLabel1.BorderStyle = BorderStyle.FixedSingle;
            linkLabel1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(12, 42);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(140, 39);
            linkLabel1.TabIndex = 0;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Sedinte";
            linkLabel1.TextAlign = ContentAlignment.TopCenter;
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.BorderStyle = BorderStyle.FixedSingle;
            linkLabel2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel2.Location = new Point(12, 109);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(140, 39);
            linkLabel2.TabIndex = 1;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Sectii";
            linkLabel2.TextAlign = ContentAlignment.TopCenter;
            linkLabel2.LinkClicked += linkLabelSectii_LinkClicked;
            // 
            // linkLabel3
            // 
            linkLabel3.BorderStyle = BorderStyle.FixedSingle;
            linkLabel3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel3.Location = new Point(12, 179);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(140, 39);
            linkLabel3.TabIndex = 2;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Dosare";
            linkLabel3.TextAlign = ContentAlignment.TopCenter;
            linkLabel3.LinkClicked += linkLabelAdaugareDosare_LinkClicked;
            // 
            // listView1
            // 
            listView1.Location = new Point(200, 42);
            listView1.Name = "listView1";
            listView1.Size = new Size(677, 369);
            listView1.TabIndex = 3;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // buttonAdaugareCont
            // 
            button1.Location = new Point(199, 446);
            button1.Name = "button1";
            button1.Size = new Size(177, 42);
            button1.TabIndex = 4;
            button1.Text = "AdaugaSedinta";
            button1.UseVisualStyleBackColor = true;
            button1.Click += buttonAdaugaSedinta_Click;
            // 
            // button2
            // 
            button2.Location = new Point(700, 446);
            button2.Name = "button2";
            button2.Size = new Size(177, 42);
            button2.TabIndex = 5;
            button2.Text = "Participa";
            button2.UseVisualStyleBackColor = true;
            button2.Click += buttonParticipa_Click;
            // 
            // buttonCreareSedinta
            // 
            buttonCreareSedinta.Location = new Point(598, 68);
            buttonCreareSedinta.Name = "buttonCreareSedinta";
            buttonCreareSedinta.Size = new Size(116, 23);
            buttonCreareSedinta.TabIndex = 6;
            buttonCreareSedinta.Text = "CreareSedinta";
            buttonCreareSedinta.UseVisualStyleBackColor = true;
            buttonCreareSedinta.Click += buttonCreareSedinta_Click;
            // 
            // labelNume
            // 
            labelNume.AutoSize = true;
            labelNume.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelNume.Location = new Point(323, 66);
            labelNume.Name = "labelNume";
            labelNume.Size = new Size(53, 21);
            labelNume.TabIndex = 7;
            labelNume.Text = "Nume";
            // 
            // labelData
            // 
            labelData.AutoSize = true;
            labelData.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelData.Location = new Point(323, 136);
            labelData.Name = "labelData";
            labelData.Size = new Size(53, 21);
            labelData.TabIndex = 8;
            labelData.Text = "Gazda";
            // 
            // labelGazda
            // 
            labelGazda.AutoSize = true;
            labelGazda.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelGazda.Location = new Point(323, 98);
            labelGazda.Name = "labelGazda";
            labelGazda.Size = new Size(42, 21);
            labelGazda.TabIndex = 9;
            labelGazda.Text = "Data";
            // 
            // textBoxNume
            // 
            textBoxNume.Location = new Point(413, 68);
            textBoxNume.Name = "textBoxNume";
            textBoxNume.Size = new Size(139, 23);
            textBoxNume.TabIndex = 10;
            // 
            // textBoxData
            // 
            textBoxData.Location = new Point(413, 100);
            textBoxData.Name = "textBoxData";
            textBoxData.Size = new Size(139, 23);
            textBoxData.TabIndex = 11;
            // 
            // textBoxGazda
            // 
            textBoxGazda.Location = new Point(413, 138);
            textBoxGazda.Name = "textBoxGazda";
            textBoxGazda.Size = new Size(139, 23);
            textBoxGazda.TabIndex = 12;
            // 
            // checkedListBoxAgenti
            // 
            checkedListBoxAgenti.FormattingEnabled = true;
            checkedListBoxAgenti.Location = new Point(373, 198);
            checkedListBoxAgenti.Name = "checkedListBoxAgenti";
            checkedListBoxAgenti.Size = new Size(323, 202);
            checkedListBoxAgenti.TabIndex = 13;
            checkedListBoxAgenti.SelectedIndexChanged += checkedListBox1_SelectedIndexChanged;
            // 
            // labelSelectareAgenti
            // 
            labelSelectareAgenti.AutoSize = true;
            labelSelectareAgenti.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelSelectareAgenti.Location = new Point(227, 216);
            labelSelectareAgenti.Name = "labelSelectareAgenti";
            labelSelectareAgenti.Size = new Size(118, 21);
            labelSelectareAgenti.TabIndex = 14;
            labelSelectareAgenti.Text = "SelectareAgenti";
            labelSelectareAgenti.Click += labelSelectareAgenti_Click;
            // 
            // button3
            // 
            button3.Location = new Point(454, 446);
            button3.Name = "button3";
            button3.Size = new Size(177, 42);
            button3.TabIndex = 15;
            button3.Text = "VizualizareSedinte";
            button3.UseVisualStyleBackColor = true;
            button3.Click += buttonVizualizareSedinte_Click;
            // 
            // linkLabel5
            // 
            linkLabel5.BorderStyle = BorderStyle.FixedSingle;
            linkLabel5.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel5.Location = new Point(12, 462);
            linkLabel5.Name = "linkLabel5";
            linkLabel5.Size = new Size(140, 39);
            linkLabel5.TabIndex = 17;
            linkLabel5.TabStop = true;
            linkLabel5.Text = "StergereCont";
            linkLabel5.TextAlign = ContentAlignment.TopCenter;
            // 
            // linkLabel4
            // 
            linkLabel4.BorderStyle = BorderStyle.FixedSingle;
            linkLabel4.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel4.Location = new Point(12, 402);
            linkLabel4.Name = "linkLabel4";
            linkLabel4.Size = new Size(140, 39);
            linkLabel4.TabIndex = 18;
            linkLabel4.TabStop = true;
            linkLabel4.Text = "AdaugareCont";
            linkLabel4.TextAlign = ContentAlignment.TopCenter;
            linkLabel4.LinkClicked += linkLabelAdaugareCont_LinkClicked;
            // 
            // PaginaPrincipalaForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(974, 525);
            Controls.Add(linkLabel4);
            Controls.Add(linkLabel5);
            Controls.Add(button3);
            Controls.Add(labelSelectareAgenti);
            Controls.Add(checkedListBoxAgenti);
            Controls.Add(textBoxGazda);
            Controls.Add(textBoxData);
            Controls.Add(textBoxNume);
            Controls.Add(labelGazda);
            Controls.Add(labelData);
            Controls.Add(labelNume);
            Controls.Add(buttonCreareSedinta);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(listView1);
            Controls.Add(linkLabel3);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Name = "PaginaPrincipalaForm";
            Text = "PaginaPrincipalaForm";
            Load += PaginaPrincipalaForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private LinkLabel linkLabel1;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel3;
        private ListView listView1;
        private Button button1;
        private Button button2;
        private Button buttonCreareSedinta;
        private Label labelNume;
        private Label labelData;
        private Label labelGazda;
        private TextBox textBoxNume;
        private TextBox textBoxData;
        private TextBox textBoxGazda;
        private CheckedListBox checkedListBoxAgenti;
        private Label labelSelectareAgenti;
        private Button button3;
        private LinkLabel linkLabel5;
        private LinkLabel linkLabel4;
    }
}