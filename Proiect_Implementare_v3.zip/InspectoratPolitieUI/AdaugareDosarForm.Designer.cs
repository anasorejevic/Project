﻿namespace InspectoratPolitieUI
{
    partial class AdaugareDosarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button3 = new Button();
            labelSelectareAgenti = new Label();
            checkedListBoxAgenti = new CheckedListBox();
            textBoxContinut = new TextBox();
            textBoxNumeDosar = new TextBox();
            label1 = new Label();
            label2 = new Label();
            buttonCreareSedinta = new Button();
            button1 = new Button();
            listView1 = new ListView();
            linkLabel3 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // button3
            // 
            button3.Location = new Point(709, 446);
            button3.Name = "button3";
            button3.Size = new Size(177, 42);
            button3.TabIndex = 44;
            button3.Text = "VizualizareDosare";
            button3.UseVisualStyleBackColor = true;
            button3.Click += buttonVizualizareDosare_Click;
            // 
            // labelSelectareAgenti
            // 
            labelSelectareAgenti.AutoSize = true;
            labelSelectareAgenti.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelSelectareAgenti.Location = new Point(237, 162);
            labelSelectareAgenti.Name = "labelSelectareAgenti";
            labelSelectareAgenti.Size = new Size(118, 21);
            labelSelectareAgenti.TabIndex = 43;
            labelSelectareAgenti.Text = "SelectareAgenti";
            // 
            // checkedListBoxAgenti
            // 
            checkedListBoxAgenti.FormattingEnabled = true;
            checkedListBoxAgenti.Location = new Point(382, 162);
            checkedListBoxAgenti.Name = "checkedListBoxAgenti";
            checkedListBoxAgenti.Size = new Size(323, 238);
            checkedListBoxAgenti.TabIndex = 42;
            // 
            // textBoxContinut
            // 
            textBoxContinut.Location = new Point(422, 100);
            textBoxContinut.Name = "textBoxLocatie";
            textBoxContinut.Size = new Size(139, 23);
            textBoxContinut.TabIndex = 41;
            // 
            // textBoxNumeDosar
            // 
            textBoxNumeDosar.Location = new Point(422, 68);
            textBoxNumeDosar.Name = "textBoxNumeSectie";
            textBoxNumeDosar.Size = new Size(139, 23);
            textBoxNumeDosar.TabIndex = 40;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(305, 98);
            label1.Name = "labelLocatie";
            label1.Size = new Size(70, 21);
            label1.TabIndex = 39;
            label1.Text = "Continut";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(305, 68);
            label2.Name = "labelNumeSectie";
            label2.Size = new Size(94, 21);
            label2.TabIndex = 38;
            label2.Text = "NumeDosar";
            // 
            // buttonCreareSedinta
            // 
            buttonCreareSedinta.Location = new Point(607, 68);
            buttonCreareSedinta.Name = "buttonCreareSedinta";
            buttonCreareSedinta.Size = new Size(116, 23);
            buttonCreareSedinta.TabIndex = 37;
            buttonCreareSedinta.Text = "CreareDosar";
            buttonCreareSedinta.UseVisualStyleBackColor = true;
            buttonCreareSedinta.Click += buttonCreareDosar_Click;
            // 
            // button1
            // 
            button1.Location = new Point(208, 446);
            button1.Name = "button1";
            button1.Size = new Size(177, 42);
            button1.TabIndex = 36;
            button1.Text = "AdaugaDosare";
            button1.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            listView1.Location = new Point(209, 42);
            listView1.Name = "listView1";
            listView1.Size = new Size(677, 369);
            listView1.TabIndex = 35;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // linkLabel3
            // 
            linkLabel3.BorderStyle = BorderStyle.FixedSingle;
            linkLabel3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel3.Location = new Point(21, 179);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(140, 39);
            linkLabel3.TabIndex = 34;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Dosare";
            linkLabel3.TextAlign = ContentAlignment.TopCenter;
            linkLabel3.LinkClicked += linkLabelDosare_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.BorderStyle = BorderStyle.FixedSingle;
            linkLabel2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel2.Location = new Point(21, 109);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(140, 39);
            linkLabel2.TabIndex = 33;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Sectii";
            linkLabel2.TextAlign = ContentAlignment.TopCenter;
            linkLabel2.LinkClicked += linkLabelSectii_LinkClicked;
            // 
            // linkLabel1
            // 
            linkLabel1.BorderStyle = BorderStyle.FixedSingle;
            linkLabel1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(21, 42);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(140, 39);
            linkLabel1.TabIndex = 32;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Sedinte";
            linkLabel1.TextAlign = ContentAlignment.TopCenter;
            linkLabel1.LinkClicked += linkLabelSedinte_LinkClicked;
            // 
            // AdaugareDosarForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1064, 552);
            Controls.Add(button3);
            Controls.Add(labelSelectareAgenti);
            Controls.Add(checkedListBoxAgenti);
            Controls.Add(textBoxContinut);
            Controls.Add(textBoxNumeDosar);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(buttonCreareSedinta);
            Controls.Add(button1);
            Controls.Add(listView1);
            Controls.Add(linkLabel3);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Name = "AdaugareDosarForm";
            Text = "AdaugareDosarForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button3;
        private Label labelSelectareAgenti;
        private CheckedListBox checkedListBoxAgenti;
        private TextBox textBoxContinut;
        private TextBox textBoxNumeDosar;
        private Label label1;
        private Label label2;
        private Button buttonCreareSedinta;
        private Button button1;
        private ListView listView1;
        private LinkLabel linkLabel3;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
    }
}