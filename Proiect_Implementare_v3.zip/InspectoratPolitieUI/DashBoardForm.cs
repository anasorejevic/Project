﻿namespace InspectoratPolitieUI
{
    public partial class DashBoardForm : Form
    {
        private string nextPage;
        public DashBoardForm()
        {
            
            InitializeComponent();
            buttonAdaugareCont.Visible = false;
        }

        public string GetNextPage()
        {
            return this.nextPage;
        }

        private void ButonAdaugareCont_Click(object sender, EventArgs e)
        {
            this.Close();
            this.nextPage = "AdaugareContForm";
        }

        private void ButonLogare_Click(object sender, EventArgs e)
        {
            this.Close();
            this.nextPage = "PaginaLogareForm";
        }

        private void DashBoardForm_Load(object sender, EventArgs e)
        {

        }
    }
}
