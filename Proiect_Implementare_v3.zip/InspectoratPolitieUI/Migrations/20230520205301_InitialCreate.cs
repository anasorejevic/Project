﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace InspectoratPolitieUI.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AdminTabel",
                columns: table => new
                {
                    IdAdmin = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AdresaEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Parola = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdminTabel", x => x.IdAdmin);
                });

            migrationBuilder.CreateTable(
                name: "DosarTabel",
                columns: table => new
                {
                    IdDosar = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NumeDosar = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Continut = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DosarTabel", x => x.IdDosar);
                });

            migrationBuilder.CreateTable(
                name: "SectiePolitieTabel",
                columns: table => new
                {
                    IdSectie = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NumeSectie = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Locatie = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SectiePolitieTabel", x => x.IdSectie);
                });

            migrationBuilder.CreateTable(
                name: "SefInspectoratTabel",
                columns: table => new
                {
                    IdSefInspectorat = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AdresaEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Parola = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SefInspectoratTabel", x => x.IdSefInspectorat);
                });

            migrationBuilder.CreateTable(
                name: "AgentPolitieTabel",
                columns: table => new
                {
                    IdAgent = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Prenume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AdresaEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Parola = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DosarModelIdDosar = table.Column<int>(type: "int", nullable: true),
                    SectiePolitieModelIdSectie = table.Column<int>(type: "int", nullable: true),
                    SedintaModelIdSedinta = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AgentPolitieTabel", x => x.IdAgent);
                    table.ForeignKey(
                        name: "FK_AgentPolitieTabel_DosarTabel_DosarModelIdDosar",
                        column: x => x.DosarModelIdDosar,
                        principalTable: "DosarTabel",
                        principalColumn: "IdDosar");
                    table.ForeignKey(
                        name: "FK_AgentPolitieTabel_SectiePolitieTabel_SectiePolitieModelIdSectie",
                        column: x => x.SectiePolitieModelIdSectie,
                        principalTable: "SectiePolitieTabel",
                        principalColumn: "IdSectie");
                });

            migrationBuilder.CreateTable(
                name: "RaportLucruTabel",
                columns: table => new
                {
                    IdRaport = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NumeRaport = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Continut = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ResponsabilIdAgent = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RaportLucruTabel", x => x.IdRaport);
                    table.ForeignKey(
                        name: "FK_RaportLucruTabel_AgentPolitieTabel_ResponsabilIdAgent",
                        column: x => x.ResponsabilIdAgent,
                        principalTable: "AgentPolitieTabel",
                        principalColumn: "IdAgent",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SedintaTabel",
                columns: table => new
                {
                    IdSedinta = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nume = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Data = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GazdaIdAgent = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SedintaTabel", x => x.IdSedinta);
                    table.ForeignKey(
                        name: "FK_SedintaTabel_AgentPolitieTabel_GazdaIdAgent",
                        column: x => x.GazdaIdAgent,
                        principalTable: "AgentPolitieTabel",
                        principalColumn: "IdAgent",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "InvitatieTabel",
                columns: table => new
                {
                    IdInvitatie = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Continut = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EvenimentIdSedinta = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InvitatieTabel", x => x.IdInvitatie);
                    table.ForeignKey(
                        name: "FK_InvitatieTabel_SedintaTabel_EvenimentIdSedinta",
                        column: x => x.EvenimentIdSedinta,
                        principalTable: "SedintaTabel",
                        principalColumn: "IdSedinta",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AgentPolitieTabel_DosarModelIdDosar",
                table: "AgentPolitieTabel",
                column: "DosarModelIdDosar");

            migrationBuilder.CreateIndex(
                name: "IX_AgentPolitieTabel_SectiePolitieModelIdSectie",
                table: "AgentPolitieTabel",
                column: "SectiePolitieModelIdSectie");

            migrationBuilder.CreateIndex(
                name: "IX_AgentPolitieTabel_SedintaModelIdSedinta",
                table: "AgentPolitieTabel",
                column: "SedintaModelIdSedinta");

            migrationBuilder.CreateIndex(
                name: "IX_InvitatieTabel_EvenimentIdSedinta",
                table: "InvitatieTabel",
                column: "EvenimentIdSedinta");

            migrationBuilder.CreateIndex(
                name: "IX_RaportLucruTabel_ResponsabilIdAgent",
                table: "RaportLucruTabel",
                column: "ResponsabilIdAgent");

            migrationBuilder.CreateIndex(
                name: "IX_SedintaTabel_GazdaIdAgent",
                table: "SedintaTabel",
                column: "GazdaIdAgent");

            migrationBuilder.AddForeignKey(
                name: "FK_AgentPolitieTabel_SedintaTabel_SedintaModelIdSedinta",
                table: "AgentPolitieTabel",
                column: "SedintaModelIdSedinta",
                principalTable: "SedintaTabel",
                principalColumn: "IdSedinta");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AgentPolitieTabel_DosarTabel_DosarModelIdDosar",
                table: "AgentPolitieTabel");

            migrationBuilder.DropForeignKey(
                name: "FK_AgentPolitieTabel_SectiePolitieTabel_SectiePolitieModelIdSectie",
                table: "AgentPolitieTabel");

            migrationBuilder.DropForeignKey(
                name: "FK_AgentPolitieTabel_SedintaTabel_SedintaModelIdSedinta",
                table: "AgentPolitieTabel");

            migrationBuilder.DropTable(
                name: "AdminTabel");

            migrationBuilder.DropTable(
                name: "InvitatieTabel");

            migrationBuilder.DropTable(
                name: "RaportLucruTabel");

            migrationBuilder.DropTable(
                name: "SefInspectoratTabel");

            migrationBuilder.DropTable(
                name: "DosarTabel");

            migrationBuilder.DropTable(
                name: "SectiePolitieTabel");

            migrationBuilder.DropTable(
                name: "SedintaTabel");

            migrationBuilder.DropTable(
                name: "AgentPolitieTabel");
        }
    }
}
