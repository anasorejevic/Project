﻿using InspectoratPolitieLibrary;
using InspectoratPolitieLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace InspectoratPolitieUI
{
    public partial class PaginaSedinteForm : Form
    {
        string nextpage;
        List<SedintaModel> sedintaLista;
        string mesaje = "";

        public PaginaSedinteForm()
        {
            InitializeComponent();

            buttonTrimite.Visible = false;
            richTextBox1.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;

            SedintaDataAccess dataAccess = new SedintaDataAccess();
            sedintaLista = dataAccess.GetAllSedinte();
            checkedListBoxSedinte.DataSource = sedintaLista;

        }

        public string GetNextPage()
        {
            return this.nextpage;
        }

        private void buttonParticipa_Click(object sender, EventArgs e)
        {
            buttonTrimite.Visible = true;
            richTextBox1.Visible = true;
            textBox1.Visible = true;
            textBox2.Visible = true;

            string numeSedinta = "-";

            for (int i = 0; i < checkedListBoxSedinte.Items.Count; i++)
            {
                if (checkedListBoxSedinte.GetItemChecked(i))
                {
                    numeSedinta = sedintaLista[i].Nume;
                    break;
                }
            }

            textBox2.Text = numeSedinta;
        }

        private void buttonTrimite_Click(object sender, EventArgs e)
        {
            mesaje = mesaje + textBox1.Text.ToString() + "\n";



            richTextBox1.Text = mesaje;

        }

        private void buttonAdaugaSedinta_Click(object sender, EventArgs e)
        {
            this.nextpage = "PaginaPrincipalaForm";
            this.Close();
        }

        private void linkLabelSectii_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "AdaugareSectieForm";
            this.Close();
        }

        private void linkLabelDosare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            nextpage = "AdaugareDosarForm";
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }









        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
