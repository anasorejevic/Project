﻿namespace InspectoratPolitieUI
{
    partial class PaginaDosareForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkedListBoxSedinte = new CheckedListBox();
            button3 = new Button();
            button1 = new Button();
            listView1 = new ListView();
            linkLabel3 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // checkedListBoxSedinte
            // 
            checkedListBoxSedinte.FormattingEnabled = true;
            checkedListBoxSedinte.Location = new Point(232, 59);
            checkedListBoxSedinte.Name = "checkedListBoxSedinte";
            checkedListBoxSedinte.Size = new Size(117, 328);
            checkedListBoxSedinte.TabIndex = 37;
            checkedListBoxSedinte.SelectedIndexChanged += checkedListBoxSedinte_SelectedIndexChanged;
            // 
            // button3
            // 
            button3.Location = new Point(707, 451);
            button3.Name = "button3";
            button3.Size = new Size(177, 42);
            button3.TabIndex = 36;
            button3.Text = "VizualizareDosare";
            button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(207, 451);
            button1.Name = "button1";
            button1.Size = new Size(177, 42);
            button1.TabIndex = 35;
            button1.Text = "AdaugaDosare";
            button1.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            listView1.Location = new Point(207, 47);
            listView1.Name = "listView1";
            listView1.Size = new Size(677, 369);
            listView1.TabIndex = 34;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // linkLabel3
            // 
            linkLabel3.BorderStyle = BorderStyle.FixedSingle;
            linkLabel3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel3.Location = new Point(20, 184);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(140, 39);
            linkLabel3.TabIndex = 33;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Dosare";
            linkLabel3.TextAlign = ContentAlignment.TopCenter;
            linkLabel3.LinkClicked += linkLabelDosare_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.BorderStyle = BorderStyle.FixedSingle;
            linkLabel2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel2.Location = new Point(20, 114);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(140, 39);
            linkLabel2.TabIndex = 32;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Sectii";
            linkLabel2.TextAlign = ContentAlignment.TopCenter;
            linkLabel2.LinkClicked += linkLabelSectii_LinkClicked;
            // 
            // linkLabel1
            // 
            linkLabel1.BorderStyle = BorderStyle.FixedSingle;
            linkLabel1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(20, 47);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(140, 39);
            linkLabel1.TabIndex = 31;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Sedinte";
            linkLabel1.TextAlign = ContentAlignment.TopCenter;
            linkLabel1.LinkClicked += linkLabelSedinte_LinkClicked;
            // 
            // PaginaDosareForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1087, 627);
            Controls.Add(checkedListBoxSedinte);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(listView1);
            Controls.Add(linkLabel3);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Name = "PaginaDosareForm";
            Text = "PaginaDosareForm";
            ResumeLayout(false);
        }

        #endregion

        private CheckedListBox checkedListBoxSedinte;
        private Button button3;
        private Button button1;
        private ListView listView1;
        private LinkLabel linkLabel3;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
    }
}