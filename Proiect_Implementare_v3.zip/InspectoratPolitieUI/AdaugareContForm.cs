﻿using InspectoratPolitieLibrary.Controllers;
using InspectoratPolitieLibrary.Models;
using InspectoratPolitieLibrary.Services;
using static System.Net.Mime.MediaTypeNames;

namespace InspectoratPolitieUI
{
    public partial class AdaugareContForm : Form
    {
        private string nextPage;
        private string utilizator_selectat;

        public AdaugareContForm()
        {
            InitializeComponent();
        }

        public string GetNextPage()
        {
            return this.nextPage;
        }

        private void ButonAdaugareCont_Click(object sender, EventArgs e)
        {            
            if (utilizator_selectat == "Agent Politie")
            {
                AgentPolitieModel agentPolitieModel = new AgentPolitieModel();
                AgentPolitieController agentPolitieController = new AgentPolitieController();
                AdaugareContService adaugareContService = new AdaugareContService();

                agentPolitieModel.Nume = textBoxNume.Text.ToString();
                agentPolitieModel.Prenume = textBoxPrenume.Text.ToString();
                agentPolitieModel.AdresaEmail = textBoxEmail.Text.ToString();
                agentPolitieModel.Parola = textBoxParola.Text.ToString();
                adaugareContService.email = textBoxEmail.Text.ToString();

                if (agentPolitieModel.VerificareDate() == true && adaugareContService.VerificareEmail() == true)
                {
                    agentPolitieController.CreateAgentPolitie(agentPolitieModel);
                    agentPolitieModel.ResetareDate();
                }
                else
                {
                    MessageBox.Show("Date invalide");
                }
            }
            else if (utilizator_selectat == "Admin")
            {
                AdminModel adminModel = new AdminModel()
                {
                    Nume = textBoxNume.Text.ToString(),
                    Prenume = textBoxPrenume.Text.ToString(),
                    AdresaEmail = textBoxEmail.Text.ToString(),
                    Parola = textBoxParola.Text.ToString(),
                    IdAdmin = 0
                };
                AdminController adminController = new AdminController();

                adminController.CreateAdmin(adminModel);

            }
            else if (utilizator_selectat == "Sef Inspectorat")
            {

            }
            else
            {
                MessageBox.Show("Tipul de utilizator nu a fost selectat");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            object selectedValue = comboBox1.SelectedItem;
            if (selectedValue != null)
            {
                string selectedItem = selectedValue.ToString();
                utilizator_selectat = selectedItem;
            }
        }

        private void buttonPaginaPrincipala_Click(object sender, EventArgs e)
        {
            nextPage = "PaginaPrincipalaForm";
            this.Close();
        }

        private void AdaugareContForm_Load(object sender, EventArgs e) { }

        private void textBox4_TextChanged(object sender, EventArgs e) { }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) { }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e) { }

        private void textBoxNume_TextChanged(object sender, EventArgs e) { }

        
    }
}
