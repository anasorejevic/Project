﻿using InspectoratPolitieLibrary;
using InspectoratPolitieLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InspectoratPolitieUI
{
    public partial class AdaugareSectieForm : Form
    {
        string nextpage;
        List<AgentPolitieModel> agentPolitieLista = new List<AgentPolitieModel>();

        public AdaugareSectieForm()
        {
            InitializeComponent();

            AgentPolitieDataAccess dataAccess = new AgentPolitieDataAccess();
            agentPolitieLista = dataAccess.GetAllAgents();
            checkedListBoxAgenti.DataSource = agentPolitieLista;
        }

        public string GetNextPage()
        {
            return this.nextpage;
        }

        private void buttonCreareSectie_Click(object sender, EventArgs e)
        {
            SectiePolitieModel sectiePolitieModel = new SectiePolitieModel();
            


            
            List<AgentPolitieModel> agentiSelectati = new List<AgentPolitieModel>();

            

            for (int i = 0; i < checkedListBoxAgenti.Items.Count; i++)
            {
                if (checkedListBoxAgenti.GetItemChecked(i))
                {
                    agentiSelectati.Add(agentPolitieLista[i]);
                }
            }

            sectiePolitieModel.AgentiPolitie = agentiSelectati;

            
            sectiePolitieModel.NumeSectie = labelNumeSectie.Text.ToString();

            string s = labelLocatie.Text.ToString();
            sectiePolitieModel.Locatie = 22;

            AdaugareSectie adaugareSectie = new AdaugareSectie(sectiePolitieModel);
            adaugareSectie.AddSectieToDb();

            MessageBox.Show("Date introduse cu succes");

        }

        private void linkLabelSedinte_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            nextpage = "PaginaPrincipalaForm";
            this.Close();

        }

        private void buttonVizualizareSectii_Click(object sender, EventArgs e)
        {
            nextpage = "PaginaSectiiPolitieForm";
            this.Close();
        }

        private void linkLabelDoasre_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            nextpage = "AdaugareDosarForm";
            this.Close();
        }

        private void buttonAdaugaSectie_Click(object sender, EventArgs e)
        {

        }

        private void PaginaSectiiPolitieForm_Load(object sender, EventArgs e)
        {

        }

        private void textBoxNume_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelSelectareAgenti_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBoxAgenti_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void textBoxLocatie_TextChanged(object sender, EventArgs e)
        {
        }

        private void labelLocatie_Click(object sender, EventArgs e)
        {
        }

        private void labelNumeSectie_Click(object sender, EventArgs e)
        {
        }

        

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
        }
    }
}
