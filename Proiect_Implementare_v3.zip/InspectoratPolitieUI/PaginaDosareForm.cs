﻿using InspectoratPolitieLibrary;
using InspectoratPolitieLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InspectoratPolitieUI
{
    public partial class PaginaDosareForm : Form
    {
        string nextpage;
        List<DosarModel> dosarLista;

        public PaginaDosareForm()
        {
            InitializeComponent();

            DosarDataAccess dataAccess = new DosarDataAccess();
            dosarLista = dataAccess.GetAllDosare();
            checkedListBoxSedinte.DataSource = dosarLista;
        }

        public string GetNextPage()
        {
            return nextpage;
        }

        private void linkLabelSectii_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "AdaugareSectieForm";
            this.Close();
        }

        private void linkLabelSedinte_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "PaginaPrincipalaForm";
            this.Close();
        }

        private void linkLabelDosare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "AdaugareDosarForm";
            this.Close();
        }

        private void checkedListBoxSedinte_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
