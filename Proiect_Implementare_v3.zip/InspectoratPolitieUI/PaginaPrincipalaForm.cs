﻿using InspectoratPolitieLibrary;
using InspectoratPolitieLibrary.Controllers;
using InspectoratPolitieLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace InspectoratPolitieUI
{
    public partial class PaginaPrincipalaForm : Form
    {
        private string nextpage;
        List<AgentPolitieModel> agentPolitieLista;
        private string usertype;

        public PaginaPrincipalaForm()
        {
            InitializeComponent();
            /*
            buttonCreareSedinta.Visible = false;
            checkedListBoxAgenti.Visible = false;
            label2.Visible = false;
            labelData.Visible = false;
            label1.Visible = false;
            labelSelectareAgenti.Visible = false;
            textBoxNumeDosar.Visible = false;
            textBoxContinut.Visible = false;
            textBoxGazda.Visible = false;
            */

            

            AgentPolitieDataAccess dataAccess = new AgentPolitieDataAccess();
            agentPolitieLista = dataAccess.GetAllAgents();
            checkedListBoxAgenti.DataSource = agentPolitieLista;
        }

        public void SetUserType(string type)
        {
            this.usertype = type;
        }
        internal string GetNextPage()
        {
            return this.nextpage;
        }


        private void buttonAdaugaSedinta_Click(object sender, EventArgs e)
        {
            buttonCreareSedinta.Visible = true;
            checkedListBoxAgenti.Visible = true;
            labelNume.Visible = true;
            labelData.Visible = true;
            labelGazda.Visible = true;
            textBoxNume.Visible = true;
            textBoxData.Visible = true;
            textBoxGazda.Visible = true;
            labelSelectareAgenti.Visible = true;
        }

        private void buttonCreareSedinta_Click(object sender, EventArgs e)
        {
            List<AgentPolitieModel> agentiSelectati = new List<AgentPolitieModel>();

            for (int i = 0; i < checkedListBoxAgenti.Items.Count; i++)
            {
                if (checkedListBoxAgenti.GetItemChecked(i))
                {
                    agentiSelectati.Add(agentPolitieLista[i]);
                }
            }

            SedintaController sedintaController = new SedintaController();
            SedintaModel sedintaModel = new SedintaModel
            {
                Nume = textBoxNume.Text.ToString(),

                Data = textBoxData.Text.ToString(),

                Participanti = agentiSelectati,

                IdSedinta = 0,

                Gazda = agentPolitieLista.First()
            };

            sedintaController.CreateSedinta(sedintaModel);
        }

        private void buttonVizualizareSedinte_Click(object sender, EventArgs e)
        {
            this.nextpage = "PaginaSedinteForm";
            this.Close();
        }

        private void linkLabelSectii_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.nextpage = "AdaugareSectieForm";
            this.Close();
        }

        private void linkLabelAdaugareDosare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            nextpage = "AdaugareDosarForm";
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void buttonParticipa_Click(object sender, EventArgs e)
        {

        }



        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            AgentPolitieModel a1 = new AgentPolitieModel("Ionn");
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void labelSelectareAgenti_Click(object sender, EventArgs e)
        {

        }

        private void PaginaPrincipalaForm_Load(object sender, EventArgs e)
        {
            if (usertype == "agent")
            {
                linkLabel5.Visible = false;
                linkLabel4.Visible = false;
            }
            else if(usertype == "admin")
            {
                linkLabel5.Visible = true;
                linkLabel4.Visible = true;
            }
        }

        private void linkLabelAdaugareCont_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            nextpage = "AdaugareContForm";
            this.Close();
        }
    }
}
