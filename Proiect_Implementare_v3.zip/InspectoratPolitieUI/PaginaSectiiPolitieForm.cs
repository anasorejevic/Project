﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InspectoratPolitieUI
{
    public partial class PaginaSectiiPolitieForm : Form
    {
        string nextpage;

        public PaginaSectiiPolitieForm()
        {
            InitializeComponent();
        }

        public string GetNextPage()
        {
            return nextpage;
        }

        private void linkLabelSedinte_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            nextpage = "PaginaPrincipalaForm";
            this.Close();
        }

        private void buttonAdaugaSectie_Click(object sender, EventArgs e)
        {
            nextpage = "AdaugareSectieForm";
            this.Close();
        }

        private void linkLabelDosare_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            nextpage = "AdaugareDosarForm";
            this.Close();
        }
    }
}
