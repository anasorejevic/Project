﻿namespace InspectoratPolitieUI
{
    partial class DashBoardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAdaugareCont = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // buttonAdaugareCont
            // 
            buttonAdaugareCont.Location = new Point(266, 335);
            buttonAdaugareCont.Name = "button1";
            buttonAdaugareCont.Size = new Size(213, 66);
            buttonAdaugareCont.TabIndex = 0;
            buttonAdaugareCont.Text = "AdaugareCont";
            buttonAdaugareCont.UseVisualStyleBackColor = true;
            buttonAdaugareCont.Click += ButonAdaugareCont_Click;
            // 
            // button2
            // 
            button2.Location = new Point(266, 224);
            button2.Name = "button2";
            button2.Size = new Size(213, 66);
            button2.TabIndex = 1;
            button2.Text = "Logare";
            button2.UseVisualStyleBackColor = true;
            button2.Click += ButonLogare_Click;
            // 
            // DashBoardForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(buttonAdaugareCont);
            Name = "DashBoardForm";
            Text = "DashBoard";
            Load += DashBoardForm_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button buttonAdaugareCont;
        private Button button2;
    }
}