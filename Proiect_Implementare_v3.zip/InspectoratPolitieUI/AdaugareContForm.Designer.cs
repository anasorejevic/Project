﻿namespace InspectoratPolitieUI
{
    partial class AdaugareContForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAdaugaCont = new Button();
            textBoxNume = new TextBox();
            textBoxPrenume = new TextBox();
            textBoxEmail = new TextBox();
            textBoxParola = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            comboBox1 = new ComboBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // buttonAdaugaCont
            // 
            buttonAdaugaCont.Location = new Point(256, 326);
            buttonAdaugaCont.Name = "buttonAdaugaCont";
            buttonAdaugaCont.Size = new Size(240, 60);
            buttonAdaugaCont.TabIndex = 0;
            buttonAdaugaCont.Text = "AdaugaCont";
            buttonAdaugaCont.UseVisualStyleBackColor = true;
            buttonAdaugaCont.Click += ButonAdaugareCont_Click;
            // 
            // textBoxNume
            // 
            textBoxNume.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxNume.Location = new Point(256, 76);
            textBoxNume.Name = "textBoxNume";
            textBoxNume.Size = new Size(240, 32);
            textBoxNume.TabIndex = 1;
            textBoxNume.TextChanged += textBoxNume_TextChanged;
            // 
            // textBoxPrenume
            // 
            textBoxPrenume.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxPrenume.Location = new Point(256, 131);
            textBoxPrenume.Name = "textBoxPrenume";
            textBoxPrenume.Size = new Size(240, 32);
            textBoxPrenume.TabIndex = 2;
            // 
            // textBoxEmail
            // 
            textBoxEmail.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxEmail.Location = new Point(256, 190);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(240, 32);
            textBoxEmail.TabIndex = 3;
            // 
            // textBoxParola
            // 
            textBoxParola.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxParola.Location = new Point(256, 247);
            textBoxParola.Name = "textBoxParola";
            textBoxParola.Size = new Size(240, 32);
            textBoxParola.TabIndex = 4;
            textBoxParola.TextChanged += textBox4_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(142, 76);
            label1.Name = "label1";
            label1.Size = new Size(63, 25);
            label1.TabIndex = 5;
            label1.Text = "Nume";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(140, 131);
            label2.Name = "label2";
            label2.Size = new Size(88, 25);
            label2.TabIndex = 6;
            label2.Text = "Prenume";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(140, 190);
            label3.Name = "label3";
            label3.Size = new Size(58, 25);
            label3.TabIndex = 7;
            label3.Text = "Email";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(140, 247);
            label4.Name = "label4";
            label4.Size = new Size(65, 25);
            label4.TabIndex = 8;
            label4.Text = "Parola";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Agent Politie", "Admin", "Sef Inspectorat" });
            comboBox1.Location = new Point(77, 326);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 11;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // buttonAdaugareCont
            // 
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(116, 32);
            button1.TabIndex = 12;
            button1.Text = "PaginaPrincipala";
            button1.UseVisualStyleBackColor = true;
            button1.Click += buttonPaginaPrincipala_Click;
            // 
            // AdaugareContForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxParola);
            Controls.Add(textBoxEmail);
            Controls.Add(textBoxPrenume);
            Controls.Add(textBoxNume);
            Controls.Add(buttonAdaugaCont);
            Name = "AdaugareContForm";
            Text = "AdaugareContForm";
            Load += AdaugareContForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonAdaugaCont;
        private TextBox textBoxNume;
        private TextBox textBoxPrenume;
        private TextBox textBoxEmail;
        private TextBox textBoxParola;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox comboBox1;
        private Button button1;
    }
}