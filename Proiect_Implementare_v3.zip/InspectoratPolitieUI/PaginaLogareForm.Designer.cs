﻿namespace InspectoratPolitieUI
{
    partial class PaginaLogareForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CreateAgent = new Button();
            Email = new TextBox();
            Prenume = new TextBox();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // CreateAgent
            // 
            CreateAgent.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            CreateAgent.Location = new Point(254, 248);
            CreateAgent.Name = "CreateAgent";
            CreateAgent.Size = new Size(250, 67);
            CreateAgent.TabIndex = 0;
            CreateAgent.Text = "Logare";
            CreateAgent.UseVisualStyleBackColor = true;
            CreateAgent.Click += buttonLogare_Click;
            // 
            // Email
            // 
            Email.Location = new Point(368, 78);
            Email.Name = "Email";
            Email.Size = new Size(217, 23);
            Email.TabIndex = 1;
            Email.TextChanged += textBoxNume_TextChanged;
            // 
            // Prenume
            // 
            Prenume.Location = new Point(368, 133);
            Prenume.Name = "Prenume";
            Prenume.Size = new Size(217, 23);
            Prenume.TabIndex = 2;
            Prenume.TextChanged += textBoxPrenume_TextChanged;
            // 
            // label2
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(221, 78);
            label1.Name = "label1";
            label1.Size = new Size(58, 25);
            label1.TabIndex = 5;
            label1.Text = "Email";
            label1.Click += label1_Click;
            // 
            // labelData
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(221, 133);
            label2.Name = "label2";
            label2.Size = new Size(65, 25);
            label2.TabIndex = 6;
            label2.Text = "Parola";
            label2.Click += label2_Click;
            // 
            // PaginaLogareForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Prenume);
            Controls.Add(Email);
            Controls.Add(CreateAgent);
            Name = "PaginaLogareForm";
            Text = "PaginaLogareForm";
            Load += PaginaLogareForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CreateAgent;
        private TextBox Email;
        private TextBox Prenume;
        private Label label1;
        private Label label2;
    }
}