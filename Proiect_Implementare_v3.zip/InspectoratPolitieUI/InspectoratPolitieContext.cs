﻿using InspectoratPolitieLibrary.Models;
using Microsoft.EntityFrameworkCore;


namespace InspectoratPolitieLibrary
{
    public class InspectoratPolitieContext : DbContext
    {
        private const string ConnectionString = "Server=(localdb)\\mssqllocaldb;Database=IPDb;Trusted_Connection=True;";

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(ConnectionString);
        }

        public DbSet<AgentPolitieModel> AgentPolitieTabel { get; set; }

        public DbSet<SectiePolitieModel> SectiePolitieTabel { get; set; }

        public DbSet<SedintaModel> SedintaTabel { get; set; }

        public DbSet<DosarModel> DosarTabel { get; set; }

        public DbSet<RaportLucruModel> RaportLucruTabel { get; set; }

        public DbSet<InvitatieModel> InvitatieTabel { get; set; }

        public DbSet<AdminModel> AdminTabel { get; set; }

        public DbSet<SefInspectoratModel> SefInspectoratTabel { get; set; }

    }
}
