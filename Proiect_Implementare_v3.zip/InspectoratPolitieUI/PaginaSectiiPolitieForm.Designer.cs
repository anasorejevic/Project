﻿namespace InspectoratPolitieUI
{
    partial class PaginaSectiiPolitieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checkedListBoxSedinte = new CheckedListBox();
            button3 = new Button();
            button1 = new Button();
            listView1 = new ListView();
            linkLabel3 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // checkedListBoxSedinte
            // 
            checkedListBoxSedinte.FormattingEnabled = true;
            checkedListBoxSedinte.Location = new Point(234, 61);
            checkedListBoxSedinte.Name = "checkedListBoxSedinte";
            checkedListBoxSedinte.Size = new Size(117, 328);
            checkedListBoxSedinte.TabIndex = 30;
            // 
            // button3
            // 
            button3.Location = new Point(709, 453);
            button3.Name = "button3";
            button3.Size = new Size(177, 42);
            button3.TabIndex = 29;
            button3.Text = "VizualizareSedinte";
            button3.UseVisualStyleBackColor = true;
            // 
            // buttonAdaugareCont
            // 
            button1.Location = new Point(209, 453);
            button1.Name = "button1";
            button1.Size = new Size(177, 42);
            button1.TabIndex = 27;
            button1.Text = "AdaugaSectie";
            button1.UseVisualStyleBackColor = true;
            button1.Click += buttonAdaugaSectie_Click;
            // 
            // listView1
            // 
            listView1.Location = new Point(209, 49);
            listView1.Name = "listView1";
            listView1.Size = new Size(677, 369);
            listView1.TabIndex = 26;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // linkLabel3
            // 
            linkLabel3.BorderStyle = BorderStyle.FixedSingle;
            linkLabel3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel3.Location = new Point(22, 186);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(140, 39);
            linkLabel3.TabIndex = 25;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "Dosare";
            linkLabel3.TextAlign = ContentAlignment.TopCenter;
            linkLabel3.LinkClicked += linkLabelDosare_LinkClicked;
            // 
            // linkLabel2
            // 
            linkLabel2.BorderStyle = BorderStyle.FixedSingle;
            linkLabel2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel2.Location = new Point(22, 116);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(140, 39);
            linkLabel2.TabIndex = 24;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Sectii";
            linkLabel2.TextAlign = ContentAlignment.TopCenter;
            // 
            // linkLabel1
            // 
            linkLabel1.BorderStyle = BorderStyle.FixedSingle;
            linkLabel1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(22, 49);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(140, 39);
            linkLabel1.TabIndex = 23;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Sedinte";
            linkLabel1.TextAlign = ContentAlignment.TopCenter;
            linkLabel1.LinkClicked += linkLabelSedinte_LinkClicked;
            // 
            // PaginaSectiiPolitieForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1075, 634);
            Controls.Add(checkedListBoxSedinte);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(listView1);
            Controls.Add(linkLabel3);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Name = "PaginaSectiiPolitieForm";
            Text = "PaginaSectiiPolitieForm";
            ResumeLayout(false);
        }

        #endregion

        private CheckedListBox checkedListBoxSedinte;
        private Button button3;
        private Button button1;
        private ListView listView1;
        private LinkLabel linkLabel3;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabel1;
    }
}