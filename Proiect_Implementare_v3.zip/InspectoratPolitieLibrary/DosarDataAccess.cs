﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary
{
    public class DosarDataAccess
    {
        private string connectionString = new MySqlAppConnection().connectionString;

        public DosarDataAccess()
        {

        }

        public List<DosarModel> GetAllDosare()
        {
            string query = "SELECT IdDosar, NumeDosar, Continut  FROM DosarTabel";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                List<DosarModel> dosarList = new List<DosarModel>();

                while (reader.Read())
                {
                    DosarModel dosar = new DosarModel
                    {
                        IdDosar = reader.GetInt32(0),
                        NumeDosar = reader.GetString(1),
                        Continut = reader.GetString(2),
                        //Participanti = reader.GetString(3),
                        //Gazda = reader.GetString(4)
                    };

                    dosarList.Add(dosar);
                }

                reader.Close();

                return dosarList;
            }
        }
    }
}
