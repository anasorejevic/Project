﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary
{
    public class SedintaDataAccess
    {
        private string connectionString = new MySqlAppConnection().connectionString;

        public SedintaDataAccess()
        {

        }

        public List<SedintaModel> GetAllSedinte()
        {
            string query = "SELECT IdSedinta, Nume, Data  FROM SedintaTabel";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                List<SedintaModel> agentList = new List<SedintaModel>();

                while (reader.Read())
                {
                    SedintaModel sedinta = new SedintaModel
                    {
                        IdSedinta = reader.GetInt32(0),
                        Nume = reader.GetString(1),
                        Data = reader.GetString(2),
                        //Participanti = reader.GetString(3),
                        //Gazda = reader.GetString(4)
                    };

                    agentList.Add(sedinta);
                }

                reader.Close();

                return agentList;
            }
        }
    }
}
