﻿using InspectoratPolitieLibrary.Controllers;
using InspectoratPolitieLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary
{
    public class AdaugaDosar
    {
        public DosarModel dosar;
        private DosarController dosarController;
        private AgentPolitieController agentPolitieController;

        public AdaugaDosar(DosarModel dosar)
        {
            this.dosar = dosar;
            dosarController = new DosarController();
            agentPolitieController = new AgentPolitieController();
        }

        public void AddDosarToDb()
        {
            dosarController.CreateDosar(this.dosar);

            for (int i = 0; i < dosar.Participanti.Count; i++)
            {
                agentPolitieController.UpdateAgentSectiePolitieId(dosar.Participanti[i].IdAgent, dosar.IdDosar);
            }
        }

    }
}
