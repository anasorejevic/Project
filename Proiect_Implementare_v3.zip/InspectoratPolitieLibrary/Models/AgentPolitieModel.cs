﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Models
{
    public class AgentPolitieModel
    {
        public string Nume { get; set; }

        public string Prenume { get; set; }

        [Key]
        public int IdAgent { get; set; }

        public string AdresaEmail { get; set; }

        public string Parola { get; set; }
      
        public AgentPolitieModel(string nume, string prenume, int idAgent, string adresaEmail, string parola)
        {
            Nume = nume;
            Prenume = prenume;
            IdAgent = idAgent;
            AdresaEmail = adresaEmail;
            Parola = parola;
        }

        public AgentPolitieModel(string nume)
        {
            Nume = nume;
            Prenume = " - ";
            IdAgent = 999;
            AdresaEmail = " - ";
            Parola =  " - ";
        }

        public AgentPolitieModel()
        {
            Nume = " ";
            Prenume = " ";
            IdAgent = 1;
            AdresaEmail = " ";
        }

        public bool VerificareDate()
        {
            bool is_valid = false;

            if (Nume != "" && Prenume != "" && AdresaEmail != "" && Parola != "")
            {
                is_valid = true;
            }

            return is_valid;
        }

        public void ResetareDate()
        {
            Nume = "";
            Prenume = "";
            AdresaEmail = "";
            Parola = "";
        }

        public override string ToString()
        {
            return $"{Nume} ";
        }
    }
}
