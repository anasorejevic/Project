﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Models
{
    public class SedintaModel
    {
        [Key]
        public int IdSedinta { get; set; }

        public string Nume { get; set; }

        public string Data { get; set; }

        public List<AgentPolitieModel> Participanti { get; set; }

        public AgentPolitieModel Gazda { get; set; }

        public override string ToString()
        {
            return $"{Nume} , {Data} ";
        }
    }
}
