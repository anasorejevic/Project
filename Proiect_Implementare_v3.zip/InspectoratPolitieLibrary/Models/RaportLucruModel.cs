﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Models
{
    public class RaportLucruModel
    {
        [Key]
        public int IdRaport { get; set; }

        public string NumeRaport { get; set; }

        public string Continut { get; set; }

        public AgentPolitieModel Responsabil { get; set; }

    }
}
