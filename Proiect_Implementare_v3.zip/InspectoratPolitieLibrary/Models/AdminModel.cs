﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Models
{
    public class AdminModel  
    {
        public string Nume { get; set; }

        public string Prenume { get; set; }

        [Key]
        public int IdAdmin { get; set; }

        public string AdresaEmail { get; set; }

        public string Parola { get; set; }
    }
}
