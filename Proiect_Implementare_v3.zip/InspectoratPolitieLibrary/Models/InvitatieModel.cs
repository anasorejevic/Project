﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Models
{
    public class InvitatieModel
    {
        [Key]
        public int IdInvitatie { get; set; }

        public string Continut { get; set; }

        public SedintaModel Eveniment { get; set; }

    }
}
