﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Models
{
    public class SectiePolitieModel
    {
        public List<AgentPolitieModel> AgentiPolitie { get; set; }

        public string NumeSectie { get; set; }

        [Key]
        public int IdSectie { get; set; }

        public int Locatie { get; set; }
    }
}
