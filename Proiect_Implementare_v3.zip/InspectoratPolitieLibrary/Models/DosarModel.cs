﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Models
{
    public class DosarModel
    {
        public string NumeDosar { get; set; }

        [Key]
        public int IdDosar { get; set; }

        public string Continut { get; set; }

        public List<AgentPolitieModel> Participanti { get; set; }
    }
}
