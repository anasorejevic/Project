﻿using InspectoratPolitieLibrary.Controllers;
using InspectoratPolitieLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary
{
    public class AdaugareSectie
    {
        public SectiePolitieModel sectie;
        private SectiePolitieController sectiePolitieController;
        AgentPolitieController agentPolitieController;

        public AdaugareSectie( SectiePolitieModel sectie )
        {
            this.sectie = sectie;
            sectiePolitieController = new SectiePolitieController();
            agentPolitieController = new AgentPolitieController();
        }

        public void AddSectieToDb()
        {
            sectiePolitieController.CreateSectiePolitie( this.sectie );

            for ( int i = 0;i < sectie.AgentiPolitie.Count; i++)
            {
                agentPolitieController.UpdateAgentSectiePolitieId(sectie.AgentiPolitie[i].IdAgent, sectie.IdSectie);
            }
        }

    }
}
