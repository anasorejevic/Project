﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary
{
    public class AgentPolitieDataAccess
    {
        private string connectionString = new MySqlAppConnection().connectionString;

        public AgentPolitieDataAccess()
        {
            
        }

        public List<AgentPolitieModel> GetAllAgents()
        {
            string query = "SELECT Nume, Prenume, IdAgent, AdresaEmail, Parola FROM AgentPolitieTabel";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                List<AgentPolitieModel> agentList = new List<AgentPolitieModel>();

                while (reader.Read())
                {
                    AgentPolitieModel agent = new AgentPolitieModel
                    {
                        Nume = reader.GetString(0),
                        Prenume = reader.GetString(1),
                        IdAgent = reader.GetInt32(2),
                        AdresaEmail = reader.GetString(3),
                        Parola = reader.GetString(4)
                    };

                    agentList.Add(agent);
                }

                reader.Close();

                return agentList;
            }
        }
    }
}
