﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Controllers
{
    public class RaportLucruController
    {
        private string connectionString;

        public RaportLucruController(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public RaportLucruController()
        {
            string connectionString = new MySqlAppConnection().connectionString;
        }

        public void CreateRaportLucru(RaportLucruModel raportLucruModel)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO RaportLucru (NumeRaport, Continut, Responsabil) VALUES (@NumeRaport, @Continut, @Responsabil); SELECT CAST(SCOPE_IDENTITY() AS INT)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@NumeRaport", raportLucruModel.NumeRaport);
                    command.Parameters.AddWithValue("@Continut", raportLucruModel.Continut);
                    command.Parameters.AddWithValue("@Responsabil", raportLucruModel.Responsabil);

                    int generatedId = (int)command.ExecuteScalar();
                    raportLucruModel.IdRaport = generatedId;
                }
            }
        }

        public void UpdateRaportLucru(int idRaport, string newNumeRaport, string newContinut, string newResponsabil)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string updateQuery = "UPDATE RaportLucru SET NumeRaport = @NewNumeRaport, Continut = @NewContinut, Responsabil = @NewResponsabil WHERE IdRaport = @IdRaport";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewNumeRaport", newNumeRaport);
                    command.Parameters.AddWithValue("@NewContinut", newContinut);
                    command.Parameters.AddWithValue("@NewResponsabil", newResponsabil);
                    command.Parameters.AddWithValue("@IdRaport", idRaport);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteRaportLucru(int idRaport)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM RaportLucru WHERE IdRaport = @IdRaport";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@IdRaport", idRaport);

                    command.ExecuteNonQuery();
                }
            }
        }
    }

}
