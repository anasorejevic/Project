﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Controllers
{
    public class SectiePolitieController
    {
        private string connectionString = new MySqlAppConnection().connectionString;

       

        public SectiePolitieController()
        {
            string connectionString = new MySqlAppConnection().connectionString;
        }

        public void CreateSectiePolitie(SectiePolitieModel sectiePolitieModel)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO SectiePolitieTabel ( NumeSectie, Locatie ) VALUES ( @NumeSectie, @Locatie ); SELECT CAST(SCOPE_IDENTITY() AS INT)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    //command.Parameters.AddWithValue("@AgentiPolitie", sectiePolitieModel.AgentiPolitie);
                    command.Parameters.AddWithValue("@NumeSectie", sectiePolitieModel.NumeSectie);
                    command.Parameters.AddWithValue("@Locatie", sectiePolitieModel.Locatie);

                    //command.ExecuteNonQuery();
                    int generatedId = (int)command.ExecuteScalar();

                    sectiePolitieModel.IdSectie = generatedId;

                }
            }
        }

        public void UpdateSectie(int idSectie, string newNumeSectie, string newAgentiPolitie, string newLocatie)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string updateQuery = "UPDATE SectiePolitieTabel SET NumeSectie = @NewNumeSectie, AgentiPolitie = @NewAgentiPolitie, Locatie = @NewLocatie WHERE IdSectie = @IdSectie";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewNumeSectie", newNumeSectie);
                    command.Parameters.AddWithValue("@NewAgentiPolitie", newAgentiPolitie);
                    command.Parameters.AddWithValue("@NewLocatie", newLocatie);
                    command.Parameters.AddWithValue("@IdSectie", idSectie);

                    command.ExecuteNonQuery();
                }
            }
        }


        public void DeleteSectie(int idSectie)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM SectiePolitieTabel WHERE IdSectie = @IdSectie";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@IdSectie", idSectie);

                    command.ExecuteNonQuery();
                }
            }
        }

    }
}
