﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Controllers
{
    public class SedintaController
    {
        private string connectionString = new MySqlAppConnection().connectionString;

        public SedintaController(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public SedintaController()
        {
            string connectionString = new MySqlAppConnection().connectionString;
        }

        public void CreateSedinta(SedintaModel sedintaModel)
        {
            

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO SedintaTabel (Nume, Data , GazdaIdAgent) VALUES (@Nume, @Data, @GazdaIdAgent); SELECT CAST(SCOPE_IDENTITY() AS INT)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Nume", sedintaModel.Nume);
                    command.Parameters.AddWithValue("@Data", sedintaModel.Data);
                    //command.Parameters.AddWithValue("@Participanti", agentArray);
                    command.Parameters.AddWithValue("@GazdaIdAgent", sedintaModel.Gazda.IdAgent);

                    int generatedId = (int)command.ExecuteScalar();
                    sedintaModel.IdSedinta = generatedId;
                }
            }
        }

        public void UpdateSedinta(int idSedinta, string newNume, DateTime newData, string newParticipanti, string newGazda)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string updateQuery = "UPDATE SedintaModel SET Nume = @NewNume, Data = @NewData, Participanti = @NewParticipanti, Gazda = @NewGazda WHERE IdSedinta = @IdSedinta";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewNume", newNume);
                    command.Parameters.AddWithValue("@NewData", newData);
                    command.Parameters.AddWithValue("@NewParticipanti", newParticipanti);
                    command.Parameters.AddWithValue("@NewGazda", newGazda);
                    command.Parameters.AddWithValue("@IdSedinta", idSedinta);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteSedinta(int idSedinta)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM SedintaModel WHERE IdSedinta = @IdSedinta";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@IdSedinta", idSedinta);

                    command.ExecuteNonQuery();
                }
            }
        }
    }

}
