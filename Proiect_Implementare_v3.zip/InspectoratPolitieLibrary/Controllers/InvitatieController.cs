﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Controllers
{
    public class InvitatieController
    {
        private string connectionString;

        public InvitatieController(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public InvitatieController()
        {
            string connectionString = new MySqlAppConnection().connectionString;
        }

        public void CreateInvitatie(InvitatieModel invitatieModel)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO Invitatie (Continut, Eveniment) VALUES (@Continut, @Eveniment); SELECT CAST(SCOPE_IDENTITY() AS INT)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Continut", invitatieModel.Continut);
                    command.Parameters.AddWithValue("@Eveniment", invitatieModel.Eveniment);

                    int generatedId = (int)command.ExecuteScalar();
                    invitatieModel.IdInvitatie = generatedId;
                }
            }
        }

        public void UpdateInvitatie(int idInvitatie, string newContinut, string newEveniment)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string updateQuery = "UPDATE Invitatie SET Continut = @NewContinut, Eveniment = @NewEveniment WHERE IdInvitatie = @IdInvitatie";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewContinut", newContinut);
                    command.Parameters.AddWithValue("@NewEveniment", newEveniment);
                    command.Parameters.AddWithValue("@IdInvitatie", idInvitatie);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteInvitatie(int idInvitatie)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM Invitatie WHERE IdInvitatie = @IdInvitatie";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@IdInvitatie", idInvitatie);

                    command.ExecuteNonQuery();
                }
            }
        }
    }

}
