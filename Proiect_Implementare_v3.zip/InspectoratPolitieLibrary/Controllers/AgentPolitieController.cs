﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Controllers
{
    public class AgentPolitieController
    {
        private string connectionString = new MySqlAppConnection().connectionString;

        public AgentPolitieController(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public AgentPolitieController()
        {
            string connectionString = new MySqlAppConnection().connectionString;
        }

        public void CreateAgentPolitie(AgentPolitieModel agentPolitie)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO AgentPolitieTabel (Nume, Prenume, AdresaEmail, Parola) VALUES (@Nume, @Prenume, @AdresaEmail, @Parola); SELECT CAST(SCOPE_IDENTITY() AS INT)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Nume", agentPolitie.Nume);
                    command.Parameters.AddWithValue("@Prenume", agentPolitie.Prenume);
                    command.Parameters.AddWithValue("@AdresaEmail", agentPolitie.AdresaEmail);
                    command.Parameters.AddWithValue("@Parola", agentPolitie.Parola);

                    //command.ExecuteNonQuery();
                    int generatedId = (int)command.ExecuteScalar();

                    agentPolitie.IdAgent = generatedId;

                }
            }
        }

        public void UpdateAgent(int idAgent, string newNume, string newPrenume, string newAdresaEmail)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string updateQuery = "UPDATE AgentPolitieTabel SET Nume = @NewNume, Prenume = @NewPrenume, AdresaEmail = @NewAdresaEmail WHERE IdAgent = @IdAgent";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewNume", newNume);
                    command.Parameters.AddWithValue("@NewPrenume", newPrenume);
                    command.Parameters.AddWithValue("@NewAdresaEmail", newAdresaEmail);
                    command.Parameters.AddWithValue("@IdAgent", idAgent);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteAgent(int idAgent)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM AgentPolitieTabel WHERE IdAgent = @IdAgent";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@IdAgent", idAgent);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void UpdateAgentSectiePolitieId(int agentId, int SectiePolitieModelIdSectie)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string updateQuery = "UPDATE AgentPolitieTabel SET SectiePolitieModelIdSectie = @SectiePolitieModelIdSectie WHERE IdAgent = @AgentId";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@SectiePolitieModelIdSectie", SectiePolitieModelIdSectie);
                    updateCommand.Parameters.AddWithValue("@AgentId", agentId);
                    updateCommand.ExecuteNonQuery();
                }
            }

            Console.WriteLine("AgentPolitieTabel updated successfully.");
        }

        public void UpdateDosarId(int agentId, int DosarModelIdDosar)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string updateQuery = "UPDATE AgentPolitieTabel SET DosarModelIdDosar = @DosarModelIdDosar WHERE IdAgent = @AgentId";
                using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                {
                    updateCommand.Parameters.AddWithValue("@DosarModelIdDosar", DosarModelIdDosar);
                    updateCommand.Parameters.AddWithValue("@AgentId", agentId);
                    updateCommand.ExecuteNonQuery();
                }
            }

            Console.WriteLine("AgentPolitieTabel updated successfully.");
        }
    }
}
