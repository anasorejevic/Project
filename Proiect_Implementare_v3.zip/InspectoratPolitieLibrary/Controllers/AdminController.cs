﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Controllers
{
    public class AdminController 
    {
        private string connectionString = new MySqlAppConnection().connectionString;

        public void CreateAdmin(AdminModel adminModel)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO AdminTabel (Nume, Prenume, AdresaEmail, Parola) VALUES (@Nume, @Prenume, @AdresaEmail, @Parola); SELECT CAST(SCOPE_IDENTITY() AS INT)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Nume", adminModel.Nume);
                    command.Parameters.AddWithValue("@Prenume", adminModel.Prenume);
                    command.Parameters.AddWithValue("@AdresaEmail", adminModel.AdresaEmail);
                    command.Parameters.AddWithValue("@Parola", adminModel.Parola);

                    //command.ExecuteNonQuery();
                    int generatedId = (int)command.ExecuteScalar();

                    adminModel.IdAdmin = generatedId;

                }
            }
        }
    }
}
