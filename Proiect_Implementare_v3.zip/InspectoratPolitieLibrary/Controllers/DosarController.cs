﻿using InspectoratPolitieLibrary.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Controllers
{
    public class DosarController
    {
        private string connectionString = new MySqlAppConnection().connectionString;



        public DosarController()
        {
            string connectionString = new MySqlAppConnection().connectionString;
        }

        public void CreateDosar(DosarModel dosarModel)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string insertQuery = "INSERT INTO DosarTabel (NumeDosar, Continut) VALUES (@NumeDosar, @Continut); SELECT CAST(SCOPE_IDENTITY() AS INT)";

                using (SqlCommand command = new SqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@NumeDosar", dosarModel.NumeDosar);
                    command.Parameters.AddWithValue("@Continut", dosarModel.Continut);
                    //command.Parameters.AddWithValue("@Participanti", dosarModel.Participanti);

                    int generatedId = (int)command.ExecuteScalar();
                    dosarModel.IdDosar = generatedId;
                }
            }
        }

        public void UpdateDosar(int idDosar, string newNumeDosar, string newContinut, string newParticipanti)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string updateQuery = "UPDATE DosarTabel SET NumeDosar = @NewNumeDosar, Continut = @NewContinut, Participanti = @NewParticipanti WHERE IdDosar = @IdDosar";

                using (SqlCommand command = new SqlCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@NewNumeDosar", newNumeDosar);
                    command.Parameters.AddWithValue("@NewContinut", newContinut);
                    command.Parameters.AddWithValue("@NewParticipanti", newParticipanti);
                    command.Parameters.AddWithValue("@IdDosar", idDosar);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteDosar(int idDosar)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string deleteQuery = "DELETE FROM DosarTabel WHERE IdDosar = @IdDosar";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@IdDosar", idDosar);

                    command.ExecuteNonQuery();
                }
            }
        }
    }

}
