﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Services
{
    public class AdaugareContService
    {
        public string email;

        string connectionString = new MySqlAppConnection().connectionString;

        public AdaugareContService(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public AdaugareContService()
        {

        }

        public bool VerificareEmail()
        {
            bool suntDateValide = true;

            // Construiește interogarea SQL pentru a verifica dacă datele se regăsesc în baza de date
            string sqlQuery = "SELECT COUNT(*) FROM AgentPolitieTabel WHERE AdresaEmail = @Email";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Adaugă parametrii pentru email și parolă în interogare
                    command.Parameters.AddWithValue("@Email", email);

                    connection.Open();

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        suntDateValide = false;
                    }

                    connection.Close();
                }
            }

            return suntDateValide;
        }

    }
}
