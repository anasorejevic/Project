﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InspectoratPolitieLibrary.Services
{
    public class LogareService
    {
        public string email;

        public string parola;

        string connectionString = new MySqlAppConnection().connectionString;

        public LogareService(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public LogareService()
        {

        }

        public bool VerificaDateAgent()
        {
            bool suntDateValide = false;

            // Construiește interogarea SQL pentru a verifica dacă datele se regăsesc în baza de date
            string sqlQuery = "SELECT COUNT(*) FROM AgentPolitieTabel WHERE AdresaEmail = @Email AND Parola = @Parola";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Adaugă parametrii pentru email și parolă în interogare
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Parola", parola);

                    connection.Open();

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        suntDateValide = true;
                    }

                    connection.Close();
                }
            }

            return suntDateValide;
        }

        public bool VerificaDateAdmin()
        {
            bool suntDateValide = false;

            // Construiește interogarea SQL pentru a verifica dacă datele se regăsesc în baza de date
            string sqlQuery = "SELECT COUNT(*) FROM AdminTabel WHERE AdresaEmail = @Email AND Parola = @Parola";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Adaugă parametrii pentru email și parolă în interogare
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Parola", parola);

                    connection.Open();

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        suntDateValide = true;
                    }

                    connection.Close();
                }
            }

            return suntDateValide;
        }

        public bool VerificaDateSefInspectorat()
        {
            bool suntDateValide = false;

            // Construiește interogarea SQL pentru a verifica dacă datele se regăsesc în baza de date
            string sqlQuery = "SELECT COUNT(*) FROM SefInspectoratTabel WHERE AdresaEmail = @Email AND Parola = @Parola";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    // Adaugă parametrii pentru email și parolă în interogare
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Parola", parola);

                    connection.Open();

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        suntDateValide = true;
                    }

                    connection.Close();
                }
            }

            return suntDateValide;
        }
    }
}
